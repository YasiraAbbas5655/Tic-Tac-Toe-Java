/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;


public class MainGamePanel extends javax.swing.JFrame {

    String HumanSign;
    String CompSign;
    String GameState[][]=new String[4][4];
    public MainGamePanel() {
        initComponents();
    }
    public void setHumanSign(String HumanSign) {
        this.HumanSign = HumanSign;
        if (HumanSign.equals("0"))
        {
            this.CompSign="1";
        }
        else
        {
            this.CompSign="0";
        }
        for (int i=0;i<4;i++)
        {
            for (int j=0;j<4;j++)
            {
                GameState[i][j]="X";
            }
            System.out.println();
        }
        Random rand=new Random();
        int value=rand.nextInt(17);
        System.out.println(value);
        System.out.println(CompSign);
        makeFirstMove(value);
        PrintStr(GameState);
    }
    public void makeFirstMove(int value)
    {
        if (value==1)
        {
            B1.setText(CompSign);
            GameState[0][0]=CompSign;
        }
        else if (value==2)
        {
            B2.setText(CompSign);
            GameState[0][1]=CompSign;
        }
        else if (value==3)
        {
            B3.setText(CompSign);
            GameState[0][2]=CompSign;
        }
        else if (value==4)
        {
            B4.setText(CompSign);
            GameState[0][3]=CompSign;
        }
        else if (value==5)
        {
            B5.setText(CompSign);
            GameState[1][0]=CompSign;
        }
        else if (value==6)
        {
            B6.setText(CompSign);
            GameState[1][1]=CompSign;
        }
        else if (value==7)
        {
            B7.setText(CompSign);
            GameState[1][2]=CompSign;
        }
        else if (value==8)
        {
            B8.setText(CompSign);
            GameState[1][3]=CompSign;
        }
        else if (value==9)
        {
            B9.setText(CompSign);
            GameState[2][0]=CompSign;
        }
        else if (value==10)
        {
            B10.setText(CompSign);
            GameState[2][1]=CompSign;
        }
        else if (value==11)
        {
            B11.setText(CompSign);
            GameState[2][2]=CompSign;
        }
        else if (value==12)
        {
            B12.setText(CompSign);
            GameState[2][3]=CompSign;
        }
        else if (value==13)
        {
            B13.setText(CompSign);
            GameState[3][0]=CompSign;
        }
        else if (value==14)
        {
            B14.setText(CompSign);
            GameState[3][1]=CompSign;
        }
        else if (value==15)
        {
            B15.setText(CompSign);
            GameState[3][2]=CompSign;
        }
        else
        {
            B16.setText(CompSign);
            GameState[3][3]=CompSign;
        }
    }
    public void PrintStr(String str[][])
    {
        for (int i=0;i<4;i++)
        {
            for (int j=0;j<4;j++)
            {
                System.out.print(str[i][j] + " ");
            }
            System.out.println();
        }
    }
    public void makeAmove()
    {
        //Initially, computer searches for three symbols in a line and tries to put fourth sign to win if possible.
        for (int i=0;i<4;i++)
        {
            if (GameState[i][0].equals(CompSign) && GameState[i][1].equals(CompSign) && GameState[i][2].equals(CompSign) && GameState[i][3].equals("X"))
            {
                if (i==0)
                {
                    B4.setText(CompSign);
                }
                if (i==1)
                {
                    B8.setText(CompSign);
                }
                if (i==2)
                {
                    B12.setText(CompSign);
                }
                if (i==3)
                {
                    B16.setText(CompSign);
                }
                GameState[i][3]=CompSign;
                JOptionPane.showMessageDialog(rootPane, "Computer Won");
                return;
            }
            if (GameState[i][0].equals(CompSign) && GameState[i][1].equals(CompSign) && GameState[i][3].equals(CompSign) && GameState[i][2].equals("X"))
            {
                if (i==0)
                {
                    B3.setText(CompSign);
                }
                if (i==1)
                {
                    B7.setText(CompSign);
                }
                if (i==2)
                {
                    B11.setText(CompSign);
                }
                if (i==3)
                {
                    B15.setText(CompSign);
                }
                GameState[i][2]=CompSign;
                JOptionPane.showMessageDialog(rootPane, "Computer Won");
                return;
            }
            if (GameState[i][0].equals(CompSign) && GameState[i][2].equals(CompSign) && GameState[i][3].equals(CompSign) && GameState[i][1].equals("X"))
            {
                if (i==0)
                {
                    B2.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B10.setText(CompSign);
                }
                if (i==3)
                {
                    B14.setText(CompSign);
                }
                GameState[i][1]=CompSign;
                JOptionPane.showMessageDialog(rootPane, "Computer Won");
                return;
            }
            if (GameState[i][1].equals(CompSign) && GameState[i][2].equals(CompSign) && GameState[i][3].equals(CompSign) && GameState[i][0].equals("X"))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                JOptionPane.showMessageDialog(rootPane, "Computer Won");
                return;
            }
            
            //PrintStr(GameState);
        }
        
        
        
        
        
        //column
        
        for (int i=0;i<4;i++)
        {
            if (GameState[0][i].equals(CompSign) && GameState[1][i].equals(CompSign) && GameState[2][i].equals(CompSign) && GameState[3][i].equals("X"))
            {
                if (i==0)
                {
                    B13.setText(CompSign);
                }
                if (i==1)
                {
                    B14.setText(CompSign);
                }
                if (i==2)
                {
                    B15.setText(CompSign);
                }
                if (i==3)
                {
                    B16.setText(CompSign);
                }
                GameState[3][i]=CompSign;
                JOptionPane.showMessageDialog(rootPane, "Computer Won");
                return;
            }
            if (GameState[0][i].equals(CompSign) && GameState[1][i].equals(CompSign) && GameState[3][i].equals(CompSign) && GameState[2][i].equals("X"))
            {
                if (i==0)
                {
                    B9.setText(CompSign);
                }
                if (i==1)
                {
                    B10.setText(CompSign);
                }
                if (i==2)
                {
                    B11.setText(CompSign);
                }
                if (i==3)
                {
                    B12.setText(CompSign);
                }
                GameState[2][i]=CompSign;
                JOptionPane.showMessageDialog(rootPane, "Computer Won");
                return;
            }
            if (GameState[0][i].equals(CompSign) && GameState[2][i].equals(CompSign) && GameState[3][i].equals(CompSign) && GameState[1][i].equals("X"))
            {
                if (i==0)
                {
                    B5.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B7.setText(CompSign);
                }
                if (i==3)
                {
                    B8.setText(CompSign);
                }
                GameState[1][i]=CompSign;
                JOptionPane.showMessageDialog(rootPane, "Computer Won");
                return;
            }
            if (GameState[1][i].equals(CompSign) && GameState[2][i].equals(CompSign) && GameState[3][i].equals(CompSign) && GameState[0][i].equals("X"))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                JOptionPane.showMessageDialog(rootPane, "Computer Won");
                return;
            }
            //PrintStr(GameState);
            
        }  
        
        
        
        
        System.out.println("1st stop");
        //If it is not possible, computer tries to block upcoming fourth sign of opponent.
        for (int i=0;i<4;i++)
        {
            if (GameState[i][0].equals(HumanSign) && GameState[i][1].equals(HumanSign) && GameState[i][2].equals(HumanSign) && GameState[i][3].equals("X"))
            {
                if (i==0)
                {
                    B4.setText(CompSign);
                }
                if (i==1)
                {
                    B8.setText(CompSign);
                }
                if (i==2)
                {
                    B12.setText(CompSign);
                }
                if (i==3)
                {
                    B16.setText(CompSign);
                }
                GameState[i][3]=CompSign;
                return;
            }
            if (GameState[i][0].equals(HumanSign) && GameState[i][1].equals(HumanSign) && GameState[i][3].equals(HumanSign) && GameState[i][2].equals("X"))
            {
                if (i==0)
                {
                    B3.setText(CompSign);
                }
                if (i==1)
                {
                    B7.setText(CompSign);
                }
                if (i==2)
                {
                    B11.setText(CompSign);
                }
                if (i==3)
                {
                    B15.setText(CompSign);
                }
                GameState[i][2]=CompSign;
                return;
            }
            if (GameState[i][0].equals(HumanSign) && GameState[i][2].equals(HumanSign) && GameState[i][3].equals(HumanSign) && GameState[i][1].equals("X"))
            {
                if (i==0)
                {
                    B2.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B10.setText(CompSign);
                }
                if (i==3)
                {
                    B14.setText(CompSign);
                }
                GameState[i][1]=CompSign;
                return;
            }
            if (GameState[i][1].equals(HumanSign) && GameState[i][2].equals(HumanSign) && GameState[i][3].equals(HumanSign) && GameState[i][0].equals("X"))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            //PrintStr(GameState);
        }
        
        
        
        
        //column
        for (int i=0;i<4;i++)
        {
            if (GameState[0][i].equals(HumanSign) && GameState[1][i].equals(HumanSign) && GameState[2][i].equals(HumanSign) && GameState[3][i].equals("X"))
            {
                if (i==0)
                {
                    B13.setText(CompSign);
                }
                if (i==1)
                {
                    B14.setText(CompSign);
                }
                if (i==2)
                {
                    B15.setText(CompSign);
                }
                if (i==3)
                {
                    B16.setText(CompSign);
                }
                GameState[3][i]=CompSign;
                return;
            }
            if (GameState[0][i].equals(HumanSign) && GameState[1][i].equals(HumanSign) && GameState[3][i].equals(HumanSign) && GameState[2][i].equals("X"))
            {
                if (i==0)
                {
                    B9.setText(CompSign);
                }
                if (i==1)
                {
                    B10.setText(CompSign);
                }
                if (i==2)
                {
                    B11.setText(CompSign);
                }
                if (i==3)
                {
                    B12.setText(CompSign);
                }
                GameState[2][i]=CompSign;
                return;
            }
            if (GameState[0][i].equals(HumanSign) && GameState[2][i].equals(HumanSign) && GameState[3][i].equals(HumanSign) && GameState[1][i].equals("X"))
            {
                if (i==0)
                {
                    B5.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B7.setText(CompSign);
                }
                if (i==3)
                {
                    B8.setText(CompSign);
                }
                GameState[1][i]=CompSign;
                return;
            }
            if (GameState[1][i].equals(HumanSign) && GameState[2][i].equals(HumanSign) && GameState[3][i].equals(HumanSign) && GameState[0][i].equals("X"))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            //PrintStr(GameState);
        }
        
        System.out.println("2nd stop");
        //If these two actions are not possible yet, computer tries to attack by putting its third sign into a line.
        
        for (int i=0;i<4;i++)
        {
            if (GameState[i][0].equals(CompSign) && GameState[i][1].equals(CompSign) && GameState[i][2].equals("X") && GameState[i][3].equals("X") )
            {
                if (i==0)
                {
                    B3.setText(CompSign);
                }
                if (i==1)
                {
                    B7.setText(CompSign);
                }
                if (i==2)
                {
                    B11.setText(CompSign);
                }
                if (i==3)
                {
                    B15.setText(CompSign);
                }
                GameState[i][2]=CompSign;
                return;
            }
            if (GameState[i][0].equals(CompSign) && GameState[i][2].equals(CompSign) && GameState[i][1].equals("X") && GameState[i][3].equals("X") )
            {
                if (i==0)
                {
                    B2.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B10.setText(CompSign);
                }
                if (i==3)
                {
                    B14.setText(CompSign);
                }
                GameState[i][1]=CompSign;
                return;
            }
            if (GameState[i][0].equals(CompSign) && GameState[i][3].equals(CompSign) && GameState[i][1].equals("X") && GameState[i][2].equals("X") )
            {
                if (i==0)
                {
                    B2.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B10.setText(CompSign);
                }
                if (i==3)
                {
                    B14.setText(CompSign);
                }
                GameState[i][1]=CompSign;
                return;
            }
            if (GameState[i][1].equals(CompSign) && GameState[i][2].equals(CompSign) && GameState[i][0].equals("X") && GameState[i][3].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            if (GameState[i][1].equals(CompSign) && GameState[i][2].equals(CompSign) && GameState[i][0].equals("X") && GameState[i][3].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            if (GameState[i][1].equals(CompSign) && GameState[i][3].equals(CompSign) && GameState[i][0].equals("X") && GameState[i][2].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            
           if (GameState[i][2].equals(CompSign) && GameState[i][3].equals(CompSign) && GameState[i][0].equals("X") && GameState[i][1].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
        }
        
        //column
        
        for (int i=0;i<4;i++)
        {
            if (GameState[0][i].equals(CompSign) && GameState[1][i].equals(CompSign) && GameState[2][i].equals("X") && GameState[3][i].equals("X") )
            {
                if (i==0)
                {
                    B9.setText(CompSign);
                }
                if (i==1)
                {
                    B10.setText(CompSign);
                }
                if (i==2)
                {
                    B11.setText(CompSign);
                }
                if (i==3)
                {
                    B12.setText(CompSign);
                }
                GameState[2][i]=CompSign;
                return;
            }
            if (GameState[0][i].equals(CompSign) && GameState[2][i].equals(CompSign) && GameState[1][i].equals("X") && GameState[3][i].equals("X") )
            {
                if (i==0)
                {
                    B5.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B7.setText(CompSign);
                }
                if (i==3)
                {
                    B8.setText(CompSign);
                }
                GameState[1][i]=CompSign;
                return;
            }
            if (GameState[0][i].equals(CompSign) && GameState[3][i].equals(CompSign) && GameState[1][i].equals("X") && GameState[2][i].equals("X") )
            {
               if (i==0)
                {
                    B5.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B7.setText(CompSign);
                }
                if (i==3)
                {
                    B8.setText(CompSign);
                }
                GameState[1][i]=CompSign;
                return;
            }
            if (GameState[1][i].equals(CompSign) && GameState[2][i].equals(CompSign) && GameState[0][i].equals("X") && GameState[3][i].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            if (GameState[1][i].equals(CompSign) && GameState[2][i].equals(CompSign) && GameState[0][i].equals("X") && GameState[3][i].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            if (GameState[1][i].equals(CompSign) && GameState[3][i].equals(CompSign) && GameState[0][i].equals("X") && GameState[2][i].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            
           if (GameState[2][i].equals(CompSign) && GameState[3][i].equals(CompSign) && GameState[0][i].equals("X") && GameState[1][i].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
        }
        
        
        
        
        
        
        System.out.println("3rd stop");
        
        //Otherwise computer blocks upcoming opponent`s third in a line.
        
        for (int i=0;i<4;i++)
        {
            if (GameState[i][0].equals(HumanSign) && GameState[i][1].equals(HumanSign) && GameState[i][2].equals("X") && GameState[i][3].equals("X") )
            {
                if (i==0)
                {
                    B3.setText(CompSign);
                }
                if (i==1)
                {
                    B7.setText(CompSign);
                }
                if (i==2)
                {
                    B11.setText(CompSign);
                }
                if (i==3)
                {
                    B15.setText(CompSign);
                }
                GameState[i][2]=CompSign;
                return;
            }
            if (GameState[i][0].equals(HumanSign) && GameState[i][2].equals(HumanSign) && GameState[i][1].equals("X") && GameState[i][3].equals("X") )
            {
                if (i==0)
                {
                    B2.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B10.setText(CompSign);
                }
                if (i==3)
                {
                    B14.setText(CompSign);
                }
                GameState[i][1]=CompSign;
                return;
            }
            if (GameState[i][0].equals(HumanSign) && GameState[i][3].equals(HumanSign) && GameState[i][1].equals("X") && GameState[i][2].equals("X") )
            {
                if (i==0)
                {
                    B2.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B10.setText(CompSign);
                }
                if (i==3)
                {
                    B14.setText(CompSign);
                }
                GameState[i][1]=CompSign;
                return;
            }
            if (GameState[i][1].equals(HumanSign) && GameState[i][2].equals(HumanSign) && GameState[i][0].equals("X") && GameState[i][3].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            if (GameState[i][1].equals(HumanSign) && GameState[i][2].equals(HumanSign) && GameState[i][0].equals("X") && GameState[i][3].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            if (GameState[i][1].equals(HumanSign) && GameState[i][3].equals(HumanSign) && GameState[i][0].equals("X") && GameState[i][2].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            
           if (GameState[i][2].equals(HumanSign) && GameState[i][3].equals(HumanSign) && GameState[i][0].equals("X") && GameState[i][1].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
        }
        
        //column
        
        for (int i=0;i<4;i++)
        {
            if (GameState[0][i].equals(HumanSign) && GameState[1][i].equals(HumanSign) && GameState[2][i].equals("X") && GameState[3][i].equals("X") )
            {
                if (i==0)
                {
                    B9.setText(CompSign);
                }
                if (i==1)
                {
                    B10.setText(CompSign);
                }
                if (i==2)
                {
                    B11.setText(CompSign);
                }
                if (i==3)
                {
                    B12.setText(CompSign);
                }
                GameState[2][i]=CompSign;
                return;
            }
            if (GameState[0][i].equals(HumanSign) && GameState[2][i].equals(HumanSign) && GameState[1][i].equals("X") && GameState[3][i].equals("X") )
            {
                if (i==0)
                {
                    B5.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B7.setText(CompSign);
                }
                if (i==3)
                {
                    B8.setText(CompSign);
                }
                GameState[1][i]=CompSign;
                return;
            }
            if (GameState[0][i].equals(HumanSign) && GameState[3][i].equals(HumanSign) && GameState[1][i].equals("X") && GameState[2][i].equals("X") )
            {
               if (i==0)
                {
                    B5.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B7.setText(CompSign);
                }
                if (i==3)
                {
                    B8.setText(CompSign);
                }
                GameState[1][i]=CompSign;
                return;
            }
            if (GameState[1][i].equals(HumanSign) && GameState[2][i].equals(HumanSign) && GameState[0][i].equals("X") && GameState[3][i].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            if (GameState[1][i].equals(HumanSign) && GameState[2][i].equals(HumanSign) && GameState[0][i].equals("X") && GameState[3][i].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            if (GameState[1][i].equals(HumanSign) && GameState[3][i].equals(HumanSign) && GameState[0][i].equals("X") && GameState[2][i].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            
           if (GameState[2][i].equals(HumanSign) && GameState[3][i].equals(HumanSign) && GameState[0][i].equals("X") && GameState[1][i].equals("X") )
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
        }
        
        System.out.println("4th stop");
        //If there is no threat of third sign in a line, program decides to attack by putting the second sign near the previous, so that it can combine four signs in a line of four.
        for (int i=0;i<4;i++)
        {
            if (GameState[i][0].equals(CompSign) && GameState[i][1].equals("X") && GameState[i][2].equals("X") && GameState[i][3].equals("X"))
            {
                if (i==0)
                {
                    B2.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B10.setText(CompSign);
                }
                if (i==3)
                {
                    B14.setText(CompSign);
                }
                GameState[i][1]=CompSign;
                return;
            }
            if (GameState[i][0].equals("X") && GameState[i][1].equals(CompSign) && GameState[i][2].equals("X") && GameState[i][3].equals("X"))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            
            if (GameState[i][0].equals("X") && GameState[i][1].equals("X") && GameState[i][2].equals(CompSign) && GameState[i][3].equals("X"))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
            if (GameState[i][0].equals("X") && GameState[i][1].equals("X") && GameState[i][2].equals("X") && GameState[i][3].equals(CompSign))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B5.setText(CompSign);
                }
                if (i==2)
                {
                    B9.setText(CompSign);
                }
                if (i==3)
                {
                    B13.setText(CompSign);
                }
                GameState[i][0]=CompSign;
                return;
            }
        }
        
        //column
        for (int i=0;i<4;i++)
        {
            if (GameState[0][i].equals(CompSign) && GameState[1][i].equals("X") && GameState[2][i].equals("X") && GameState[3][i].equals("X"))
            {
                if (i==0)
                {
                    B5.setText(CompSign);
                }
                if (i==1)
                {
                    B6.setText(CompSign);
                }
                if (i==2)
                {
                    B7.setText(CompSign);
                }
                if (i==3)
                {
                    B8.setText(CompSign);
                }
                GameState[1][i]=CompSign;
                return;
            }
            if (GameState[0][i].equals("X") && GameState[1][i].equals(CompSign) && GameState[2][i].equals("X") && GameState[3][i].equals("X"))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            
            if (GameState[0][i].equals("X") && GameState[1][i].equals("X") && GameState[2][i].equals(CompSign) && GameState[3][i].equals("X"))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
            if (GameState[0][1].equals("X") && GameState[1][i].equals("X") && GameState[2][i].equals("X") && GameState[3][i].equals(CompSign))
            {
                if (i==0)
                {
                    B1.setText(CompSign);
                }
                if (i==1)
                {
                    B2.setText(CompSign);
                }
                if (i==2)
                {
                    B3.setText(CompSign);
                }
                if (i==3)
                {
                    B4.setText(CompSign);
                }
                GameState[0][i]=CompSign;
                return;
            }
        }
        
        System.out.println("5th stop");
        //Make Random Move
        ArrayList<RC> arr=new ArrayList<RC>();
        for (int i=0;i<4;i++)
        {
            for (int j=0;j<4;j++)
            {
                if (GameState[i][j]=="X")
                {
                    RC temp=new RC(i,j);
                    arr.add(temp);
                }
            }
        }
        
        RC newTemp=getRandom(arr);
        
        System.out.println(newTemp.getRow());
        System.out.println(newTemp.getCol());
        if (newTemp.getRow()==0 && newTemp.getCol()==0)
        {
            B1.setText(CompSign);
        }
        if (newTemp.getRow()==0 && newTemp.getCol()==1)
        {
            B2.setText(CompSign);
        }
        if (newTemp.getRow()==0 && newTemp.getCol()==2)
        {
            B3.setText(CompSign);
        }
        if (newTemp.getRow()==0 && newTemp.getCol()==3)
        {
            B4.setText(CompSign);
        }
        if (newTemp.getRow()==1 && newTemp.getCol()==0)
        {
        B5.setText(CompSign);
        }
        if (newTemp.getRow()==1 && newTemp.getCol()==1)
        {
            B6.setText(CompSign);
        }
        if (newTemp.getRow()==1 && newTemp.getCol()==2)
        {
            B7.setText(CompSign);
        }
        if (newTemp.getRow()==1 && newTemp.getCol()==3)
        {
            B8.setText(CompSign);
        }
        if (newTemp.getRow()==2 && newTemp.getCol()==0)
        {
            B9.setText(CompSign);
        }
        if (newTemp.getRow()==2 && newTemp.getCol()==1)
        {
            B10.setText(CompSign);
        }
        if (newTemp.getRow()==2 && newTemp.getCol()==2)
        {
            B11.setText(CompSign);
        }
        if (newTemp.getRow()==2 && newTemp.getCol()==3)
        {
            B12.setText(CompSign);
        }
        if (newTemp.getRow()==3 && newTemp.getCol()==0)
        {
            B13.setText(CompSign);
        }
        if (newTemp.getRow()==3 && newTemp.getCol()==1)
        {
            B14.setText(CompSign);
        }
        if (newTemp.getRow()==3 && newTemp.getCol()==2)
        {
            B15.setText(CompSign);
        }
        if (newTemp.getRow()==3 && newTemp.getCol()==3)
        {
            B16.setText(CompSign);
        }
        GameState[newTemp.getRow()][newTemp.getCol()]=CompSign;
        return;
    }
    
    public RC getRandom(ArrayList<RC> array) {
    int rnd = new Random().nextInt(array.size());
    return array.get(rnd);
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        B1 = new javax.swing.JButton();
        B2 = new javax.swing.JButton();
        B3 = new javax.swing.JButton();
        B4 = new javax.swing.JButton();
        B5 = new javax.swing.JButton();
        B6 = new javax.swing.JButton();
        B7 = new javax.swing.JButton();
        B8 = new javax.swing.JButton();
        B9 = new javax.swing.JButton();
        B10 = new javax.swing.JButton();
        B11 = new javax.swing.JButton();
        B12 = new javax.swing.JButton();
        B13 = new javax.swing.JButton();
        B14 = new javax.swing.JButton();
        B15 = new javax.swing.JButton();
        B16 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new java.awt.GridLayout(4, 4, 1, 1));

        B1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B1ActionPerformed(evt);
            }
        });
        jPanel1.add(B1);

        B2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B2ActionPerformed(evt);
            }
        });
        jPanel1.add(B2);

        B3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B3ActionPerformed(evt);
            }
        });
        jPanel1.add(B3);

        B4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B4ActionPerformed(evt);
            }
        });
        jPanel1.add(B4);

        B5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B5ActionPerformed(evt);
            }
        });
        jPanel1.add(B5);

        B6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B6ActionPerformed(evt);
            }
        });
        jPanel1.add(B6);

        B7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B7ActionPerformed(evt);
            }
        });
        jPanel1.add(B7);

        B8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B8ActionPerformed(evt);
            }
        });
        jPanel1.add(B8);

        B9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B9ActionPerformed(evt);
            }
        });
        jPanel1.add(B9);

        B10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B10ActionPerformed(evt);
            }
        });
        jPanel1.add(B10);

        B11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B11ActionPerformed(evt);
            }
        });
        jPanel1.add(B11);

        B12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B12ActionPerformed(evt);
            }
        });
        jPanel1.add(B12);

        B13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B13ActionPerformed(evt);
            }
        });
        jPanel1.add(B13);

        B14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B14ActionPerformed(evt);
            }
        });
        jPanel1.add(B14);

        B15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B15ActionPerformed(evt);
            }
        });
        jPanel1.add(B15);

        B16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B16ActionPerformed(evt);
            }
        });
        jPanel1.add(B16);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 114, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void B12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B12ActionPerformed
        if(B12.getText().toString().equals(""))
        {
            B12.setText(HumanSign);
            GameState[2][3]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B12ActionPerformed

    private void B1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B1ActionPerformed
        if(B1.getText().toString().equals(""))
        {
            B1.setText(HumanSign);
            GameState[0][0]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B1ActionPerformed

    private void B2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B2ActionPerformed
        if(B2.getText().toString().equals(""))
        {
            B2.setText(HumanSign);
            GameState[0][1]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B2ActionPerformed

    private void B3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B3ActionPerformed
        if(B3.getText().toString().equals(""))
        {
            B3.setText(HumanSign);
            GameState[0][2]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B3ActionPerformed

    private void B4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B4ActionPerformed
        if(B4.getText().toString().equals(""))
        {
            B4.setText(HumanSign);
            GameState[0][3]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B4ActionPerformed

    private void B5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B5ActionPerformed
        if(B5.getText().toString().equals(""))
        {
            B5.setText(HumanSign);
            GameState[1][0]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B5ActionPerformed

    private void B6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B6ActionPerformed
        if(B6.getText().toString().equals(""))
        {
            B6.setText(HumanSign);
            GameState[1][1]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B6ActionPerformed

    private void B7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B7ActionPerformed
        if(B7.getText().toString().equals(""))
        {
            B7.setText(HumanSign);
            GameState[1][2]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B7ActionPerformed

    private void B8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B8ActionPerformed
        if(B8.getText().toString().equals(""))
        {
            B8.setText(HumanSign);
            GameState[1][3]=HumanSign;
            makeAmove();
            //PrintStr(GameState);
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B8ActionPerformed

    private void B9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B9ActionPerformed
        if(B9.getText().toString().equals(""))
        {
            B9.setText(HumanSign);
            GameState[2][0]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B9ActionPerformed

    private void B10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B10ActionPerformed
        if(B10.getText().toString().equals(""))
        {
            B10.setText(HumanSign);
            GameState[2][1]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B10ActionPerformed

    private void B11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B11ActionPerformed
        if(B11.getText().toString().equals(""))
        {
            B11.setText(HumanSign);
            GameState[2][2]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B11ActionPerformed

    private void B13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B13ActionPerformed
        if(B13.getText().toString().equals(""))
        {
            B13.setText(HumanSign);
            GameState[3][0]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B13ActionPerformed

    private void B14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B14ActionPerformed
        if(B14.getText().toString().equals(""))
        {
            B14.setText(HumanSign);
            GameState[3][1]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B14ActionPerformed

    private void B15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B15ActionPerformed
        if(B15.getText().toString().equals(""))
        {
            B15.setText(HumanSign);
            GameState[3][2]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B15ActionPerformed

    private void B16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B16ActionPerformed
        if(B16.getText().toString().equals(""))
        {
            B16.setText(HumanSign);
            GameState[3][3]=HumanSign;
            makeAmove();
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, "Already Marked");
        }
    }//GEN-LAST:event_B16ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainGamePanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainGamePanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainGamePanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainGamePanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainGamePanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton B1;
    private javax.swing.JButton B10;
    private javax.swing.JButton B11;
    private javax.swing.JButton B12;
    private javax.swing.JButton B13;
    private javax.swing.JButton B14;
    private javax.swing.JButton B15;
    private javax.swing.JButton B16;
    private javax.swing.JButton B2;
    private javax.swing.JButton B3;
    private javax.swing.JButton B4;
    private javax.swing.JButton B5;
    private javax.swing.JButton B6;
    private javax.swing.JButton B7;
    private javax.swing.JButton B8;
    private javax.swing.JButton B9;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
